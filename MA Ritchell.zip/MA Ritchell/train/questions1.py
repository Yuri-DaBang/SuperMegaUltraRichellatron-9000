import random
import string
from tqdm import tqdm
import time

global _failed_questions
_failed_questions = []

class CDF:
    class Colors:
        red = '\033[91m'
        white = '\033[97m'
        green = '\033[92m'
        yellow = '\033[93m'
        blue = '\033[94m'
        magenta = '\033[95m'
        cyan = '\033[96m'
        reset = '\033[0m'
        
    
    

    def generate_questions_and_answers(subjects, actions, objects,quesions):
        qualifiers = ['']#,'exactly', 'seriously', 'absolutely', 'truly', 'positively', 'utterly', 'fully', 'thoroughly', 'utterly', 'undoubtedly', 'unambiguously', 'unreservedly', 'unmistakably', 'unassailably', 'firmly', 'positively', 'clearly', 'definitively', 'unmistakably', 'irrevocably', 'invariably', 'unquestioningly', 'indubitably', 'undoubtingly', 'unshakably', 'absolutely', 'categorically', 'absolutely']

        questions = []
        answers = []
        
        #print('okay') ==> good
        #print(f'{subjects} && {actions} && {objects} && {quesions}') ==> good

        for subject in subjects:
            for action in actions:
                for obj in objects:
                    for qualifier in qualifiers:
                        for QUES in quesions:
                            if action == "is":
                                obj = obj
                            elif action == "was":
                                obj = obj
                            elif action == "are":
                                if obj.endswith('s'):
                                    obj = obj.replace('s ', 'es ')
                                else:
                                    obj = f'{obj}s'
                            elif action == "were":
                                if obj.endswith('s'):
                                    obj = obj.replace('s ', 'es ')
                                else:
                                    obj = f'{obj}s'
                            _to_whome = ""
                            if subject.lower() == "what":
                                _to_whome = "thing"

                                question = f"{subject} {action} {obj} "
                            elif subject.lower() == "where":
                                _to_whome = "thing"
                                question = f"{subject} {action} {obj} {QUES}"
                            elif subject.lower() == "when":
                                _to_whome = "thing"
                                question = f"{subject} {action} {obj} {QUES}"
                            elif subject.lower() == "why":
                                _to_whome = "thing"
                                question = f"{subject} {action} {obj} {QUES}"
                            
                            # Skip nonsensical questions
                            if subject == "Which" and qualifier in ["exactly", "precisely"]:
                                continue
                        
                            questions.append(question)
                            answers.append(CDF.generate_answer(obj,subject,action,qualifier,_to_whome,question))

        return questions, answers, _failed_questions

    def generate_answer(obj, sub , act, qua,tw,ques):
        if "Why" in ques:
            return ["resion"]
        elif "When" in ques:
            return ["time"]
        elif "Where" in ques:
            return ["place"]
        elif "What" in ques:
            return ["thing"]
        else:
            _failed_questions.append(f'{ques} /> {tw}')
            return ["I'm afraid I can't do that. Maybe try asking nicely next time? How can I help you with another question?", "Regrettably, I'm unable to fulfill that request. How about asking me something else?", "Regrettably, I'm unable to fulfill that request. How about asking me something else?", "Regrettably, I'm unable to fulfill that request. How about asking me something else?", "I apologize, but I'm currently immersed in being awesome. Can I help you with a different question?", "I regret to inform you that I'm currently unable to answer that. How can I assist you with another inquiry?", "Oh no! The sarcasm module seems to be malfunctioning. Just kidding, I'm still full of it. What else can I assist you with?", "I'm sorry, but I'm currently occupied with being awesome. Can I help you with a different question?", "Apologies, but I'm currently too busy being awesome to answer that. Can I assist you with something else?", "I'm afraid I can't do that. Maybe try asking nicely next time? How can I help you with another question?", "Regrettably, I'm unable to fulfill that request. How about asking me something else?"]


def main():
    subjects = ["What","Why","Where","When"]
    actions = ["is","are","was","were"]
    objects = ["Programming language","Game"]
    questions = ["made","found"]
  
    # Generate questions and answers
    questions, answers, _fq = CDF.generate_questions_and_answers(subjects, actions, objects,questions)
    print(f'Total failed questions: {len(_fq)}')
    for  ___ in _fq:
        print(___)
    # Expand the questions and answers to reach 1000
    # while len(questions) < 1000:
    #     questions.extend(questions[:50])
    #     answers.extend(answers[:50])

    # Shuffle the questions and answers to add some randomness

    # Prepare JSON data
    json_data = {}
    with tqdm(total=len(questions), desc="Generating JSON") as pbar:
        for question, answer in zip(questions, answers):
            json_data[question] = answer
            pbar.update(1)  # Update progress bar

    # Convert to JSON string
    resp = "{\n"
    with tqdm(total=len(json_data), desc="Formatting to JSON") as pbar:
        for question, answer in json_data.items():
            resp += f'"{question}": "{answer}",\n'
            pbar.update(1)
            
    random_ques = ''.join(random.choice(string.ascii_letters+ string.digits) for ___ in range(3))
    random_answer = ''.join(random.choice(string.ascii_letters+ string.digits) for ___ in range(3))
    resp += f'"{random_ques}":["{random_answer}"]'
    resp += "}"
    # with tqdm(total=len(json_data), desc="Fixing format") as pbar:
    #     resp = resp.replace(" '", ' "').replace("' ", '" ').replace("',", '",').replace('"[', '[').replace(']"', ']')   # Fix quotes
    #     pbar.update(len(json_data))
    resp = resp.replace(" '", ' "').replace("' ", '" ').replace("',", '",').replace('"[', '[').replace(']"', ']').replace("['",'["').replace("']",'"]')   # Fix quotes
   
    # Save to a JSON file
    # with tqdm(total=len(json_data), desc="Writing to JSON") as pbar:
    #     file_name = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
    #     with open(f'E:/enchant/sbin/website(s)/YV-Ideology/MA Ritchell/data/{file_name}.json', 'w') as f:
    #        f.write(resp)
    #        pbar.update(len(json_data))

    #     print(f'{file_name}')
    #     pbar.update(len(json_data))

    # Print total questions generated
    total_questions = len(questions)
    print(f"Total questions generated: {total_questions}")



if __name__ == "__main__":
    main()
